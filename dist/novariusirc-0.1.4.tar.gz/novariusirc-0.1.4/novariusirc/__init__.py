"""NovariusIRC package metadata."""

__version__ = "0.1.4"
__all__ = ["__version__"]
